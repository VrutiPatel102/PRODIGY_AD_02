
package com.example.todolist.Model;

public class ToDoModel {
    private int id;
    private int status; // 0 for incomplete, 1 for complete
    private String task;
    private String date; // Field for date

    // Default constructor
    public ToDoModel() {}

    // Parameterized constructor
    public ToDoModel(int id, String task, int status, String date) {
        this.id = id;
        this.task = task;
        this.status = status;
        this.date = date;
    }

    // Getter and setter for id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter and setter for status
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    // Getter and setter for task
    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    // Getter and setter for date
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
