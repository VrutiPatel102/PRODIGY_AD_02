package com.example.todolist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.example.todolist.Adapter.ToDoAdapter;

public class RecyclerItemTouchHelper extends ItemTouchHelper.SimpleCallback {

    private final ToDoAdapter adapter;
    private final Context context;

    public RecyclerItemTouchHelper(ToDoAdapter adapter, Context context) {
        super(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT);
        this.adapter = adapter;
        this.context = context;
    }

    @Override
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
        return false; // We don't support moving items
    }

    @Override
    public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
        final int position = viewHolder.getAdapterPosition();
        if (direction == ItemTouchHelper.LEFT) {
            showDeleteConfirmationDialog(position, viewHolder);
        } else if (direction == ItemTouchHelper.RIGHT) {
            adapter.editItem(position);
        }
    }

    private void showDeleteConfirmationDialog(final int position, final RecyclerView.ViewHolder viewHolder) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Task")
                .setMessage("Are you sure you want to delete this task?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adapter.deleteItem(position);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adapter.notifyItemChanged(viewHolder.getAdapterPosition());
                    }
                })
                .create()
                .show();
    }

    @Override
    public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                            float dx, float dy, int actionState, boolean isCurrentlyActive) {
        super.onChildDraw(c, recyclerView, viewHolder, dx, dy, actionState, isCurrentlyActive);

        Drawable icon;
        ColorDrawable background;
        View itemView = viewHolder.itemView;
        int backgroundCornerOffset = 20;

        if (dx > 0) { // Swiping to the right (edit)
            icon = ContextCompat.getDrawable(context, R.drawable.baseline_edit_24);
            background = new ColorDrawable(ContextCompat.getColor(context, R.color.colorAccent));
        } else if (dx < 0) { // Swiping to the left (delete)
            icon = ContextCompat.getDrawable(context, R.drawable.baseline_delete_24);
            background = new ColorDrawable(Color.RED);
        } else { // No swipe action
            background = new ColorDrawable(Color.TRANSPARENT);
            icon = null;
        }

        drawBackgroundAndIcon(c, itemView, dx, background, icon, backgroundCornerOffset);
    }

    private void drawBackgroundAndIcon(Canvas c, View itemView, float dx, ColorDrawable background, Drawable icon, int backgroundCornerOffset) {
        if (icon != null) {
            int iconMargin = (itemView.getHeight() - icon.getIntrinsicHeight()) / 2;
            int iconTop = itemView.getTop() + iconMargin;
            int iconBottom = iconTop + icon.getIntrinsicHeight();

            if (dx > 0) { // Swiping to the right (edit)
                int iconLeft = itemView.getLeft() + iconMargin;
                int iconRight = itemView.getLeft() + iconMargin + icon.getIntrinsicWidth();
                icon.setBounds(iconLeft, iconTop, iconRight, iconBottom);
                background.setBounds(itemView.getLeft(), itemView.getTop(), itemView.getLeft() + (int) dx + backgroundCornerOffset, itemView.getBottom());
            } else if (dx < 0) { // Swiping to the left (delete)
                int iconLeft = itemView.getRight() - iconMargin - icon.getIntrinsicWidth();
                int iconRight = itemView.getRight() - iconMargin;
                icon.setBounds(iconLeft, iconTop, iconRight, iconBottom);
                background.setBounds(itemView.getRight() + (int) dx - backgroundCornerOffset, itemView.getTop(), itemView.getRight(), itemView.getBottom());
            }

            background.draw(c);
            icon.draw(c);
        } else {
            background.setBounds(0, 0, 0, 0);
            background.draw(c);
        }
    }
}
