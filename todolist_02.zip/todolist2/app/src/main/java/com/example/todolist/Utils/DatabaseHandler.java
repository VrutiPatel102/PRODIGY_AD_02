package com.example.todolist.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.example.todolist.Model.ToDoModel;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String NAME = "toDoListDatabase";
    private static final String TABLE_NAME = "tasks";
    private static final String ID = "id";
    private static final String TASK = "task";
    private static final String STATUS = "status";
    private static final String DATE = "date";
    private SQLiteDatabase db;

    public DatabaseHandler(Context context) {
        super(context, NAME, null, VERSION);
        openDatabase(); // Open the database only once
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + TASK + " TEXT, "
                + STATUS + " INTEGER, "
                + DATE + " TEXT)";
        db.execSQL(createTable);
        Log.d("DatabaseHandler", "Table created: " + createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
        Log.d("DatabaseHandler", "Table upgraded");
    }

    public void openDatabase() {
        if (db == null || !db.isOpen()) {
            db = this.getWritableDatabase();
            Log.d("DatabaseHandler", "Database opened");
        }
        // Check if the table exists
        if (!tableExists(db, TABLE_NAME)) {
            onCreate(db);
            Log.d("DatabaseHandler", "Table created");
        }
    }

    private boolean tableExists(SQLiteDatabase db, String tableName) {
        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "'", null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public void insertTask(ToDoModel task) {
        Log.d("DatabaseHandler", "Inserting task: " + task.getTask());
        ContentValues values = new ContentValues();
        values.put(TASK, task.getTask());
        values.put(STATUS, task.getStatus());
        values.put(DATE, task.getDate());
        long id = db.insert(TABLE_NAME, null, values);
        Log.d("DatabaseHandler", "Task inserted with ID: " + id);
    }

    public void updateStatus(int id, int status) {
        ContentValues cv = new ContentValues();
        cv.put(STATUS, status);
        int rows = db.update(TABLE_NAME, cv, ID + "=?", new String[]{String.valueOf(id)});
        Log.d("DatabaseHandler", "Status updated, rows affected: " + rows);
    }

    public void updateTask(int id, String task, String date) {
        ContentValues cv = new ContentValues();
        cv.put(TASK, task);
        cv.put(DATE, date);
        int rows = db.update(TABLE_NAME, cv, ID + "=?", new String[]{String.valueOf(id)});
        Log.d("DatabaseHandler", "Task updated, rows affected: " + rows);
    }

    public void deleteTask(int id) {
        int rows = db.delete(TABLE_NAME, ID + "=?", new String[]{String.valueOf(id)});
        Log.d("DatabaseHandler", "Task deleted, rows affected: " + rows);
    }

    public List<ToDoModel> getAllTasks() {
        List<ToDoModel> taskList = new ArrayList<>();
        Cursor cur = null;
        try {
            cur = db.query(TABLE_NAME, null, null, null, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                do {
                    ToDoModel task = new ToDoModel();
                    task.setId(cur.getInt(cur.getColumnIndexOrThrow(ID)));
                    task.setTask(cur.getString(cur.getColumnIndexOrThrow(TASK)));
                    task.setStatus(cur.getInt(cur.getColumnIndexOrThrow(STATUS)));
                    task.setDate(cur.getString(cur.getColumnIndexOrThrow(DATE)));
                    taskList.add(task);
                } while (cur.moveToNext());
            }
            // Add logging statement to verify task list
            Log.d("DatabaseHandler", "Tasks retrieved: " + taskList.size());
        } catch (Exception e) {
            Log.e("DatabaseHandler", "Error reading from database", e);
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return taskList;
    }
}